ROS CHALLENGE PROJECT

##############################

Jacques Die 3407929

Mael Fayolle 15009140

##############################

 FOLDERS :

 Bag : recorded datas used for task2 of challenge 3 (more infos on readme launch3)

 Launch : launchfiles used for different challenges.

 Map : Map created for the task 2 of challenge 3  (more infos on readme launch3)

 Rviz : rviz configuration

 scripts : where the magic happen, each files is commented briefly at the start to summarize the method used

 urdf : models of our bots

 worlds : to load the world of the different challenges


 #################################
